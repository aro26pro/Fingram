import express from "express";
import session from "express-session";
import Database from "better-sqlite3";
import crypto from "node:crypto";
import nodemailer from "nodemailer";
import path from "node:path";
import { fileURLToPath } from "node:url";

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const app = express();
const isProduction = process.env.NODE_ENV === "production";
const db = new Database(path.join(__dirname, "connect.db"));
db.pragma("journal_mode = WAL");
db.pragma("busy_timeout = 5000");
db.pragma("foreign_keys = ON");

db.exec(`
  CREATE TABLE IF NOT EXISTS users (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    name TEXT NOT NULL,
    email TEXT NOT NULL UNIQUE,
    password_hash TEXT NOT NULL,
    salt TEXT NOT NULL,
    email_verified INTEGER NOT NULL DEFAULT 0,
    verification_token_hash TEXT,
    verification_expires_at INTEGER,
    bio TEXT NOT NULL DEFAULT '',
    status TEXT NOT NULL DEFAULT 'active',
    created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
  );

  CREATE TABLE IF NOT EXISTS posts (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id INTEGER NOT NULL,
    body TEXT NOT NULL,
    created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
  );

  CREATE TABLE IF NOT EXISTS post_likes (
    post_id INTEGER NOT NULL,
    user_id INTEGER NOT NULL,
    created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (post_id, user_id),
    FOREIGN KEY (post_id) REFERENCES posts(id) ON DELETE CASCADE,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
  );

  CREATE TABLE IF NOT EXISTS comments (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    post_id INTEGER NOT NULL,
    user_id INTEGER NOT NULL,
    body TEXT NOT NULL,
    created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (post_id) REFERENCES posts(id) ON DELETE CASCADE,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
  );

  CREATE TABLE IF NOT EXISTS follows (
    follower_id INTEGER NOT NULL,
    following_id INTEGER NOT NULL,
    created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (follower_id, following_id),
    CHECK (follower_id <> following_id),
    FOREIGN KEY (follower_id) REFERENCES users(id) ON DELETE CASCADE,
    FOREIGN KEY (following_id) REFERENCES users(id) ON DELETE CASCADE
  );

  CREATE TABLE IF NOT EXISTS blocks (
    blocker_id INTEGER NOT NULL,
    blocked_id INTEGER NOT NULL,
    created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (blocker_id, blocked_id),
    CHECK (blocker_id <> blocked_id),
    FOREIGN KEY (blocker_id) REFERENCES users(id) ON DELETE CASCADE,
    FOREIGN KEY (blocked_id) REFERENCES users(id) ON DELETE CASCADE
  );

  CREATE TABLE IF NOT EXISTS reports (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    reporter_id INTEGER NOT NULL,
    post_id INTEGER,
    reported_user_id INTEGER,
    reason TEXT NOT NULL,
    details TEXT NOT NULL DEFAULT '',
    status TEXT NOT NULL DEFAULT 'open',
    reviewed_at TEXT,
    created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (reporter_id) REFERENCES users(id) ON DELETE CASCADE,
    FOREIGN KEY (post_id) REFERENCES posts(id) ON DELETE CASCADE,
    FOREIGN KEY (reported_user_id) REFERENCES users(id) ON DELETE CASCADE
  );

  CREATE TABLE IF NOT EXISTS friend_requests (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    sender_id INTEGER NOT NULL,
    receiver_id INTEGER NOT NULL,
    status TEXT NOT NULL DEFAULT 'pending',
    created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
    CHECK (sender_id <> receiver_id),
    FOREIGN KEY (sender_id) REFERENCES users(id) ON DELETE CASCADE,
    FOREIGN KEY (receiver_id) REFERENCES users(id) ON DELETE CASCADE
  );

  CREATE UNIQUE INDEX IF NOT EXISTS friend_pair_unique ON friend_requests(sender_id, receiver_id);
`);

app.disable("x-powered-by");
app.set("trust proxy", 1);
app.use((req, res, next) => {
  res.setHeader("X-Content-Type-Options", "nosniff");
  res.setHeader("X-Frame-Options", "DENY");
  res.setHeader("Referrer-Policy", "strict-origin-when-cross-origin");
  res.setHeader("Permissions-Policy", "camera=(), microphone=(), geolocation=()");
  res.setHeader("Cross-Origin-Opener-Policy", "same-origin");
  if (isProduction) res.setHeader("Strict-Transport-Security", "max-age=31536000; includeSubDomains");
  next();
});
app.use(express.json({ limit: "32kb" }));

const requestCounts = new Map();
function rateLimit(windowMs, max) {
  return (req, res, next) => {
    const key = `${req.ip}:${req.path}`;
    const now = Date.now();
    let item = requestCounts.get(key);
    if (!item || now - item.start >= windowMs) item = { start: now, count: 0 };
    item.count += 1; requestCounts.set(key, item);
    if (item.count > max) return res.status(429).json({ error: "Too many requests. Please try again shortly." });
    next();
  };
}
setInterval(() => { const cutoff = Date.now() - 15 * 60 * 1000; for (const [k,v] of requestCounts) if (v.start < cutoff) requestCounts.delete(k); }, 5 * 60 * 1000).unref();
try { db.exec("ALTER TABLE users ADD COLUMN email_verified INTEGER NOT NULL DEFAULT 0"); } catch {}
try { db.exec("ALTER TABLE users ADD COLUMN verification_token_hash TEXT"); } catch {}
try { db.exec("ALTER TABLE users ADD COLUMN verification_expires_at INTEGER"); } catch {}
try { db.exec("ALTER TABLE users ADD COLUMN bio TEXT NOT NULL DEFAULT ''"); } catch {}
try { db.exec("ALTER TABLE users ADD COLUMN status TEXT NOT NULL DEFAULT 'active'"); } catch {}
try { db.exec("ALTER TABLE reports ADD COLUMN reviewed_at TEXT"); } catch {}

db.exec(`CREATE TABLE IF NOT EXISTS admin_audit (id INTEGER PRIMARY KEY AUTOINCREMENT, action TEXT NOT NULL, target_type TEXT, target_id INTEGER, details TEXT NOT NULL DEFAULT '', created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP)`);

const mailer = (process.env.SMTP_HOST && process.env.SMTP_USER && process.env.SMTP_PASS)
  ? nodemailer.createTransport({
      host: process.env.SMTP_HOST || "smtp.gmail.com",
      port: Number(process.env.SMTP_PORT || 587),
      secure: String(process.env.SMTP_SECURE || "false") === "true",
      auth: { user: process.env.SMTP_USER, pass: process.env.SMTP_PASS }
    }) : null;

function makeVerificationToken() { return crypto.randomBytes(32).toString("hex"); }
function hashToken(token) { return crypto.createHash("sha256").update(token).digest("hex"); }

async function sendVerificationEmail(email, name, token) {
  if (!mailer) throw new Error("Email service is not configured.");
  const base = (process.env.APP_URL || "http://localhost:3000").replace(/\/$/, "");
  const verifyUrl = `${base}/verify-email?token=${encodeURIComponent(token)}`;
  const safeName = String(name).replace(/[<>&"]/g, "");
  await mailer.sendMail({
    from: process.env.EMAIL_FROM || process.env.SMTP_USER,
    to: email,
    subject: "Verify your Fingram email",
    text: `Hi ${name},\n\nVerify your Fingram email: ${verifyUrl}\n\nThis link expires in 24 hours.`,
    html: `<p>Hi ${safeName},</p><p>Verify your Fingram email to activate your account:</p><p><a href="${verifyUrl}">Verify my email</a></p><p>This link expires in 24 hours.</p>`
  });
}

app.get("/healthz", (req, res) => res.status(200).json({ ok: true, service: "fingram" }));
app.get("/readyz", (req, res) => {
  try { db.prepare("SELECT 1").get(); res.status(200).json({ ok: true }); }
  catch { res.status(503).json({ ok: false }); }
});

app.use(express.static(path.join(__dirname, "public"), { maxAge: isProduction ? "1h" : 0 }));

if (isProduction && !process.env.SESSION_SECRET) {
  throw new Error("SESSION_SECRET must be set in production.");
}
app.use(session({
  secret: process.env.SESSION_SECRET || crypto.randomBytes(32).toString("hex"),
  resave: false,
  saveUninitialized: false,
  cookie: {
    httpOnly: true,
    sameSite: "lax",
    secure: false,
    maxAge: 1000 * 60 * 60 * 24 * 7
  }
}));

function hashPassword(password, salt = crypto.randomBytes(16).toString("hex")) {
  const hash = crypto.scryptSync(password, salt, 64).toString("hex");
  return { hash, salt };
}

function publicUser(user) {
  return { id: user.id, name: user.name, email: user.email, bio: user.bio || "", created_at: user.created_at };
}

function requireAdmin(req, res, next) {
  if (!req.session.admin) return res.status(401).json({ error: "Administrator authentication required." });
  next();
}

function audit(action, targetType = null, targetId = null, details = "") {
  db.prepare("INSERT INTO admin_audit (action, target_type, target_id, details) VALUES (?, ?, ?, ?)").run(action, targetType, targetId, details);
}

function requireAuth(req, res, next) {
  if (!req.session.userId) return res.status(401).json({ error: "You are not logged in." });
  const user = db.prepare("SELECT status FROM users WHERE id = ?").get(req.session.userId);
  if (!user) { req.session.destroy(() => {}); return res.status(401).json({ error: "You are not logged in." }); }
  if (user.status === "suspended") { req.session.destroy(() => {}); return res.status(403).json({ error: "This account is suspended. Please contact Fingram support." }); }
  next();
}


app.get("/verify-email", (req, res) => {
  const token = String(req.query.token || "");
  if (!token) return res.status(400).send("<h2>Invalid verification link</h2><p>This link is missing a token.</p>");
  const user = db.prepare("SELECT id, email_verified, verification_expires_at FROM users WHERE verification_token_hash = ?").get(hashToken(token));
  if (!user) return res.status(400).send("<h2>Invalid verification link</h2><p>The link may have already been used.</p>");
  if (user.email_verified) return res.send("<h2>Email already verified</h2><p>You can return to Fingram and log in.</p>");
  if (!user.verification_expires_at || user.verification_expires_at < Date.now())
    return res.status(410).send("<h2>Verification link expired</h2><p>Please request a new verification email.</p>");
  db.prepare("UPDATE users SET email_verified = 1, verification_token_hash = NULL, verification_expires_at = NULL WHERE id = ?").run(user.id);
  res.send('<!doctype html><meta name="viewport" content="width=device-width"><title>Fingram email verified</title><style>body{font-family:system-ui;background:#f5f7fb;display:grid;place-items:center;min-height:100vh}.card{background:white;padding:32px;border-radius:18px;text-align:center;box-shadow:0 15px 45px #0001}a{display:inline-block;margin-top:14px;background:#2563eb;color:white;padding:11px 18px;border-radius:9px;text-decoration:none}</style><div class="card"><h1>✓ Email verified</h1><p>Your Fingram account is ready.</p><a href="/">Log in to Fingram</a></div>');
});

app.post("/api/resend-verification", rateLimit(15 * 60 * 1000, 5), async (req, res) => {
  const email = String(req.body.email || "").trim().toLowerCase();
  const user = db.prepare("SELECT id, name, email, email_verified FROM users WHERE email = ?").get(email);
  if (!user || user.email_verified) return res.json({ ok: true });
  if (!mailer) return res.status(503).json({ error: "Email service is not configured." });
  const token = makeVerificationToken();
  db.prepare("UPDATE users SET verification_token_hash = ?, verification_expires_at = ? WHERE id = ?")
    .run(hashToken(token), Date.now() + 24 * 60 * 60 * 1000, user.id);
  try {
    await sendVerificationEmail(user.email, user.name, token);
    res.json({ ok: true });
  } catch {
    res.status(503).json({ error: "Could not send the verification email." });
  }
});

app.get("/api/me", (req, res) => {
  if (!req.session.userId) return res.json({ user: null });
  const user = db.prepare("SELECT id, name, email, bio, created_at FROM users WHERE id = ?").get(req.session.userId);
  if (!user) {
    req.session.destroy(() => {});
    return res.json({ user: null });
  }
  res.json({ user: publicUser(user) });
});

app.post("/api/register", rateLimit(15 * 60 * 1000, 5), async (req, res) => {
  const name = String(req.body.name || "").trim();
  const email = String(req.body.email || "").trim().toLowerCase();
  const password = String(req.body.password || "");

  if (name.length < 2) return res.status(400).json({ error: "Enter your name." });
  if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) return res.status(400).json({ error: "Enter a valid email." });
  if (email.length > 254) return res.status(400).json({ error: "Email address is too long." });
  if (password.length < 8) return res.status(400).json({ error: "Password must be at least 8 characters." });

  try {
    const { hash, salt } = hashPassword(password);
    const result = db.prepare(
      "INSERT INTO users (name, email, password_hash, salt) VALUES (?, ?, ?, ?)"
    ).run(name, email, hash, salt);

    const userId = result.lastInsertRowid;
    const token = makeVerificationToken();
    db.prepare("UPDATE users SET verification_token_hash = ?, verification_expires_at = ? WHERE id = ?")
      .run(hashToken(token), Date.now() + 24 * 60 * 60 * 1000, userId);
    try {
      await sendVerificationEmail(email, name, token);
    } catch {
      db.prepare("DELETE FROM users WHERE id = ?").run(userId);
      return res.status(503).json({ error: "We could not send the verification email. Please try again later." });
    }
    res.status(201).json({ verificationRequired: true, email });
  } catch (err) {
    if (String(err.message).includes("UNIQUE")) {
      return res.status(409).json({ error: "An account with that email already exists." });
    }
    res.status(500).json({ error: "Could not create the account." });
  }
});

app.post("/api/login", rateLimit(15 * 60 * 1000, 10), (req, res) => {
  const email = String(req.body.email || "").trim().toLowerCase();
  const password = String(req.body.password || "");
  const user = db.prepare("SELECT * FROM users WHERE email = ?").get(email);

  if (!user) return res.status(401).json({ error: "Email or password is incorrect." });

  const { hash } = hashPassword(password, user.salt);
  const valid = crypto.timingSafeEqual(
    Buffer.from(hash, "hex"),
    Buffer.from(user.password_hash, "hex")
  );

  if (!valid) return res.status(401).json({ error: "Email or password is incorrect." });
  if (!user.email_verified) return res.status(403).json({ error: "Please verify your email before logging in.", code: "EMAIL_NOT_VERIFIED" });
  if (user.status === "suspended") return res.status(403).json({ error: "This account is suspended. Please contact Fingram support." });

  req.session.userId = user.id;
  res.json({ user: publicUser(user) });
});

app.post("/api/logout", requireAuth, (req, res) => {
  req.session.destroy(() => res.json({ ok: true }));
});


app.get("/admin", (req, res) => res.sendFile(path.join(__dirname, "public", "admin.html")));

app.post("/api/admin/login", rateLimit(15 * 60 * 1000, 8), (req, res) => {
  const email = String(req.body.email || "").trim().toLowerCase();
  const password = String(req.body.password || "");
  const adminEmail = String(process.env.ADMIN_EMAIL || "").trim().toLowerCase();
  const adminPassword = String(process.env.ADMIN_PASSWORD || "");
  if (!adminEmail || !adminPassword) return res.status(503).json({ error: "Administrator credentials are not configured on the server." });
  if (email !== adminEmail || password !== adminPassword) return res.status(401).json({ error: "Administrator email or password is incorrect." });
  req.session.admin = true;
  req.session.adminEmail = adminEmail;
  res.json({ ok: true, email: adminEmail });
});

app.post("/api/admin/logout", requireAdmin, (req, res) => {
  delete req.session.admin;
  delete req.session.adminEmail;
  res.json({ ok: true });
});

app.get("/api/admin/me", (req, res) => res.json({ admin: Boolean(req.session.admin), email: req.session.adminEmail || null }));

app.get("/api/admin/stats", requireAdmin, (req, res) => {
  const users = db.prepare("SELECT COUNT(*) AS n FROM users").get().n;
  const verified = db.prepare("SELECT COUNT(*) AS n FROM users WHERE email_verified = 1").get().n;
  const suspended = db.prepare("SELECT COUNT(*) AS n FROM users WHERE status = 'suspended'").get().n;
  const posts = db.prepare("SELECT COUNT(*) AS n FROM posts").get().n;
  const comments = db.prepare("SELECT COUNT(*) AS n FROM comments").get().n;
  const openReports = db.prepare("SELECT COUNT(*) AS n FROM reports WHERE status = 'open'").get().n;
  const friends = db.prepare("SELECT COUNT(*) AS n FROM friend_requests WHERE status = 'accepted'").get().n;
  const follows = db.prepare("SELECT COUNT(*) AS n FROM follows").get().n;
  const recent = db.prepare("SELECT id, action, target_type, target_id, details, created_at FROM admin_audit ORDER BY id DESC LIMIT 20").all();
  res.json({ users, verified, suspended, posts, comments, openReports, friends, follows, recent });
});

app.get("/api/admin/users", requireAdmin, (req, res) => {
  const q = String(req.query.q || "").trim();
  const like = `%${q.replace(/[%_]/g, "\\$&").slice(0, 100)}%`;
  const users = db.prepare(`
    SELECT u.id, u.name, u.email, u.email_verified, u.status, u.created_at,
      (SELECT COUNT(*) FROM posts p WHERE p.user_id=u.id) AS posts,
      (SELECT COUNT(*) FROM reports r WHERE r.reported_user_id=u.id AND r.status='open') AS open_reports
    FROM users u
    WHERE (? = '' OR u.name LIKE ? ESCAPE '\\' OR u.email LIKE ? ESCAPE '\\')
    ORDER BY u.id DESC LIMIT 100
  `).all(q, like, like);
  res.json({ users });
});

app.post("/api/admin/users/:id/suspend", requireAdmin, (req, res) => {
  const id = Number(req.params.id);
  if (!Number.isInteger(id)) return res.status(400).json({ error: "Invalid user." });
  const user = db.prepare("SELECT id, email, status FROM users WHERE id=?").get(id);
  if (!user) return res.status(404).json({ error: "User not found." });
  const next = user.status === "suspended" ? "active" : "suspended";
  db.prepare("UPDATE users SET status=? WHERE id=?").run(next, id);
  audit(next === "suspended" ? "suspend_user" : "unsuspend_user", "user", id, user.email);
  res.json({ status: next });
});

app.delete("/api/admin/users/:id", requireAdmin, (req, res) => {
  const id = Number(req.params.id);
  if (!Number.isInteger(id)) return res.status(400).json({ error: "Invalid user." });
  const user = db.prepare("SELECT id, email FROM users WHERE id=?").get(id);
  if (!user) return res.status(404).json({ error: "User not found." });
  db.prepare("DELETE FROM users WHERE id=?").run(id);
  audit("delete_user", "user", id, user.email);
  res.json({ ok: true });
});

app.get("/api/admin/reports", requireAdmin, (req, res) => {
  const reports = db.prepare(`
    SELECT r.id, r.reason, r.details, r.status, r.created_at, r.reviewed_at,
      reporter.name AS reporter_name,
      reported.name AS reported_user_name,
      p.body AS post_body, p.id AS post_id
    FROM reports r
    JOIN users reporter ON reporter.id=r.reporter_id
    LEFT JOIN users reported ON reported.id=r.reported_user_id
    LEFT JOIN posts p ON p.id=r.post_id
    ORDER BY CASE WHEN r.status='open' THEN 0 ELSE 1 END, r.id DESC LIMIT 100
  `).all();
  res.json({ reports });
});

app.post("/api/admin/reports/:id/status", requireAdmin, (req, res) => {
  const id = Number(req.params.id);
  const status = String(req.body.status || "").toLowerCase();
  if (!Number.isInteger(id) || !["open", "resolved", "dismissed"].includes(status)) return res.status(400).json({ error: "Invalid report update." });
  const result = db.prepare("UPDATE reports SET status=?, reviewed_at=CURRENT_TIMESTAMP WHERE id=?").run(status, id);
  if (!result.changes) return res.status(404).json({ error: "Report not found." });
  audit("report_" + status, "report", id, "");
  res.json({ ok: true, status });
});

app.get("/api/admin/posts", requireAdmin, (req, res) => {
  const posts = db.prepare(`
    SELECT p.id, p.body, p.created_at, u.id AS user_id, u.name, u.email,
      (SELECT COUNT(*) FROM post_likes pl WHERE pl.post_id=p.id) AS likes,
      (SELECT COUNT(*) FROM comments c WHERE c.post_id=p.id) AS comments
    FROM posts p JOIN users u ON u.id=p.user_id ORDER BY p.id DESC LIMIT 100
  `).all();
  res.json({ posts });
});

app.delete("/api/admin/posts/:id", requireAdmin, (req, res) => {
  const id = Number(req.params.id);
  if (!Number.isInteger(id)) return res.status(400).json({ error: "Invalid post." });
  const post = db.prepare("SELECT id, user_id FROM posts WHERE id=?").get(id);
  if (!post) return res.status(404).json({ error: "Post not found." });
  db.prepare("DELETE FROM posts WHERE id=?").run(id);
  audit("delete_post", "post", id, `user ${post.user_id}`);
  res.json({ ok: true });
});

app.post("/api/account/delete", requireAuth, rateLimit(15 * 60 * 1000, 3), (req, res) => {
  const userId = req.session.userId;
  db.prepare("DELETE FROM users WHERE id = ?").run(userId);
  req.session.destroy(() => res.json({ ok: true }));
});

app.post("/api/users/:id/block", requireAuth, (req, res) => {
  const id = Number(req.params.id);
  if (!Number.isInteger(id) || id === req.session.userId) return res.status(400).json({ error: "Invalid user." });
  if (!db.prepare("SELECT id FROM users WHERE id = ?").get(id)) return res.status(404).json({ error: "User not found." });
  const existing = db.prepare("SELECT 1 FROM blocks WHERE blocker_id = ? AND blocked_id = ?").get(req.session.userId, id);
  if (existing) db.prepare("DELETE FROM blocks WHERE blocker_id = ? AND blocked_id = ?").run(req.session.userId, id);
  else {
    db.prepare("INSERT INTO blocks (blocker_id, blocked_id) VALUES (?, ?)").run(req.session.userId, id);
    db.prepare("DELETE FROM follows WHERE (follower_id = ? AND following_id = ?) OR (follower_id = ? AND following_id = ?)").run(req.session.userId, id, id, req.session.userId);
    db.prepare("DELETE FROM friend_requests WHERE (sender_id = ? AND receiver_id = ?) OR (sender_id = ? AND receiver_id = ?)").run(req.session.userId, id, id, req.session.userId);
  }
  res.json({ blocked: !existing });
});

app.post("/api/reports", requireAuth, rateLimit(15 * 60 * 1000, 10), (req, res) => {
  const postId = req.body.postId == null ? null : Number(req.body.postId);
  const reportedUserId = req.body.userId == null ? null : Number(req.body.userId);
  const reason = String(req.body.reason || "").trim().slice(0, 80);
  const details = String(req.body.details || "").trim().slice(0, 500);
  if (!reason) return res.status(400).json({ error: "Choose a reason." });
  if (!postId && !reportedUserId) return res.status(400).json({ error: "Choose a post or user to report." });
  if (postId && !db.prepare("SELECT id FROM posts WHERE id = ?").get(postId)) return res.status(404).json({ error: "Post not found." });
  if (reportedUserId && !db.prepare("SELECT id FROM users WHERE id = ?").get(reportedUserId)) return res.status(404).json({ error: "User not found." });
  db.prepare("INSERT INTO reports (reporter_id, post_id, reported_user_id, reason, details) VALUES (?, ?, ?, ?, ?)").run(req.session.userId, postId, reportedUserId, reason, details);
  res.status(201).json({ ok: true });
});

app.get("/privacy", (req, res) => res.type("html").send(`<!doctype html><html><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Fingram Privacy Policy</title></head><body style="font-family:system-ui;max-width:760px;margin:40px auto;padding:0 20px;line-height:1.6"><h1>Fingram Privacy Policy</h1><p>Fingram collects account information such as name and email, authentication data, profile content, posts, comments, follows and friend connections to provide the service. Verification emails are sent through the configured email provider. We do not store your Google password.</p><p>We use reasonable technical safeguards and retain account data while the account is active, subject to legitimate security or legal retention needs.</p><h2>Account deletion</h2><p>Signed-in users can request account deletion from the app. Account deletion removes the account and associated application records, subject to limited legally required retention.</p><h2>Contact</h2><p>Replace this paragraph with your real privacy contact before publishing on Google Play.</p></body></html>`));
app.get("/terms", (req, res) => res.type("html").send(`<!doctype html><html><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Fingram Terms</title></head><body style="font-family:system-ui;max-width:760px;margin:40px auto;padding:0 20px;line-height:1.6"><h1>Fingram Terms of Use</h1><p>Use Fingram respectfully and only post content you are allowed to share. Do not harass, threaten, impersonate, spam, or post illegal or abusive content. We may remove content or restrict accounts that violate these rules.</p><p>By creating an account, you agree to these Terms of Use and the Fingram Privacy Policy.</p><p>Replace this paragraph with your legal developer/contact information before publishing on Google Play.</p></body></html>`));

app.get("/api/profile/:id", requireAuth, (req, res) => {
  const id = Number(req.params.id);
  if (!Number.isInteger(id)) return res.status(400).json({ error: "Invalid profile." });
  const user = db.prepare(`
    SELECT id, name, bio, created_at,
      (SELECT COUNT(*) FROM posts p WHERE p.user_id = users.id) AS post_count,
      (SELECT COUNT(*) FROM follows f WHERE f.following_id = users.id) AS followers_count,
      (SELECT COUNT(*) FROM follows f WHERE f.follower_id = users.id) AS following_count
    FROM users WHERE id = ?
  `).get(id);
  if (!user) return res.status(404).json({ error: "Profile not found." });
  const posts = db.prepare(`
    SELECT p.id, p.user_id, p.body, p.created_at,
      (SELECT COUNT(*) FROM post_likes pl WHERE pl.post_id = p.id) AS likes,
      EXISTS(SELECT 1 FROM post_likes pl2 WHERE pl2.post_id = p.id AND pl2.user_id = ?) AS liked,
      (SELECT COUNT(*) FROM comments c WHERE c.post_id = p.id) AS comments_count
    FROM posts p WHERE p.user_id = ? ORDER BY p.id DESC LIMIT 50
  `).all(req.session.userId, id);
  const following = Boolean(db.prepare("SELECT 1 FROM follows WHERE follower_id = ? AND following_id = ?").get(req.session.userId, id));
  let friendStatus = "none";
  const outgoing = db.prepare("SELECT status FROM friend_requests WHERE sender_id = ? AND receiver_id = ? ORDER BY id DESC LIMIT 1").get(req.session.userId, id);
  const incoming = db.prepare("SELECT status FROM friend_requests WHERE sender_id = ? AND receiver_id = ? ORDER BY id DESC LIMIT 1").get(id, req.session.userId);
  if (outgoing?.status === "accepted" || incoming?.status === "accepted") friendStatus = "friends";
  else if (outgoing?.status === "pending") friendStatus = "outgoing";
  else if (incoming?.status === "pending") friendStatus = "incoming";
  res.json({ profile: { ...user, following, friend_status: friendStatus }, posts: posts.map(p => ({ ...p, liked: Boolean(p.liked) })) });
});

app.get("/api/users/search", requireAuth, (req, res) => {
  const q = String(req.query.q || "").trim();
  if (q.length < 2) return res.json({ users: [] });
  const like = `%${q.replace(/[%_]/g, "\\$&")}%`;
  const users = db.prepare(`
    SELECT id, name, bio,
      (SELECT COUNT(*) FROM follows f WHERE f.following_id = users.id) AS followers_count
    FROM users WHERE id <> ? AND (name LIKE ? ESCAPE '\\' OR email LIKE ? ESCAPE '\\')
    ORDER BY name COLLATE NOCASE LIMIT 20
  `).all(req.session.userId, like, like);
  res.json({ users });
});

app.get("/api/friends", requireAuth, (req, res) => {
  const id = req.session.userId;
  const friends = db.prepare(`
    SELECT u.id, u.name, u.bio, u.created_at
    FROM friend_requests fr JOIN users u ON u.id = CASE WHEN fr.sender_id = ? THEN fr.receiver_id ELSE fr.sender_id END
    WHERE (fr.sender_id = ? OR fr.receiver_id = ?) AND fr.status = 'accepted'
    ORDER BY u.name COLLATE NOCASE
  `).all(id, id, id);
  const following = db.prepare(`SELECT u.id, u.name, u.bio FROM follows f JOIN users u ON u.id = f.following_id WHERE f.follower_id = ? ORDER BY u.name COLLATE NOCASE`).all(id);
  const incoming = db.prepare(`SELECT fr.id, u.id AS user_id, u.name, u.bio FROM friend_requests fr JOIN users u ON u.id = fr.sender_id WHERE fr.receiver_id = ? AND fr.status = 'pending' ORDER BY fr.id DESC`).all(id);
  res.json({ friends, following, incoming });
});

app.post("/api/users/:id/follow", requireAuth, (req, res) => {
  const id = Number(req.params.id);
  if (!Number.isInteger(id) || id === req.session.userId) return res.status(400).json({ error: "Invalid user." });
  if (!db.prepare("SELECT id FROM users WHERE id = ?").get(id)) return res.status(404).json({ error: "User not found." });
  const existing = db.prepare("SELECT 1 FROM follows WHERE follower_id = ? AND following_id = ?").get(req.session.userId, id);
  if (existing) db.prepare("DELETE FROM follows WHERE follower_id = ? AND following_id = ?").run(req.session.userId, id);
  else db.prepare("INSERT INTO follows (follower_id, following_id) VALUES (?, ?)").run(req.session.userId, id);
  const followers = db.prepare("SELECT COUNT(*) AS count FROM follows WHERE following_id = ?").get(id).count;
  res.json({ following: !existing, followers });
});

app.post("/api/users/:id/friend-request", requireAuth, (req, res) => {
  const id = Number(req.params.id);
  if (!Number.isInteger(id) || id === req.session.userId) return res.status(400).json({ error: "Invalid user." });
  if (!db.prepare("SELECT id FROM users WHERE id = ?").get(id)) return res.status(404).json({ error: "User not found." });
  const reverse = db.prepare("SELECT id, status FROM friend_requests WHERE sender_id = ? AND receiver_id = ? ORDER BY id DESC LIMIT 1").get(id, req.session.userId);
  if (reverse?.status === "pending") {
    db.prepare("UPDATE friend_requests SET status = 'accepted', updated_at = CURRENT_TIMESTAMP WHERE id = ?").run(reverse.id);
    return res.json({ status: "friends" });
  }
  const existing = db.prepare("SELECT id, status FROM friend_requests WHERE sender_id = ? AND receiver_id = ? ORDER BY id DESC LIMIT 1").get(req.session.userId, id);
  if (existing?.status === "pending") return res.json({ status: "outgoing" });
  if (existing?.status === "accepted") return res.json({ status: "friends" });
  if (existing) db.prepare("UPDATE friend_requests SET status = 'pending', updated_at = CURRENT_TIMESTAMP WHERE id = ?").run(existing.id);
  else db.prepare("INSERT INTO friend_requests (sender_id, receiver_id) VALUES (?, ?)").run(req.session.userId, id);
  res.json({ status: "outgoing" });
});

app.post("/api/friend-requests/:id/accept", requireAuth, (req, res) => {
  const id = Number(req.params.id);
  const request = db.prepare("SELECT id FROM friend_requests WHERE id = ? AND receiver_id = ? AND status = 'pending'").get(id, req.session.userId);
  if (!request) return res.status(404).json({ error: "Friend request not found." });
  db.prepare("UPDATE friend_requests SET status = 'accepted', updated_at = CURRENT_TIMESTAMP WHERE id = ?").run(id);
  res.json({ status: "friends" });
});

app.post("/api/friend-requests/:id/decline", requireAuth, (req, res) => {
  const id = Number(req.params.id);
  const result = db.prepare("UPDATE friend_requests SET status = 'declined', updated_at = CURRENT_TIMESTAMP WHERE id = ? AND receiver_id = ? AND status = 'pending'").run(id, req.session.userId);
  if (!result.changes) return res.status(404).json({ error: "Friend request not found." });
  res.json({ status: "declined" });
});

app.patch("/api/profile", requireAuth, (req, res) => {
  const name = String(req.body.name || "").trim();
  const bio = String(req.body.bio || "").trim();
  if (name.length < 2 || name.length > 80) return res.status(400).json({ error: "Name must be 2–80 characters." });
  if (bio.length > 160) return res.status(400).json({ error: "Bio can be up to 160 characters." });
  db.prepare("UPDATE users SET name = ?, bio = ? WHERE id = ?").run(name, bio, req.session.userId);
  const user = db.prepare("SELECT id, name, email, bio, created_at FROM users WHERE id = ?").get(req.session.userId);
  res.json({ user: publicUser(user) });
});


app.get("/api/feed", requireAuth, (req, res) => {
  const viewerId = req.session.userId;
  const posts = db.prepare(`
    SELECT p.id, p.user_id, p.body, p.created_at, u.name,
      (SELECT COUNT(*) FROM post_likes pl WHERE pl.post_id = p.id) AS likes,
      EXISTS(SELECT 1 FROM post_likes pl2 WHERE pl2.post_id = p.id AND pl2.user_id = ?) AS liked,
      (SELECT COUNT(*) FROM comments c WHERE c.post_id = p.id) AS comments_count
    FROM posts p
    JOIN users u ON u.id = p.user_id
    ORDER BY p.id DESC
    LIMIT 50
  `).all(viewerId);

  const commentStmt = db.prepare(`
    SELECT c.id, c.body, c.created_at, c.user_id, u.name
    FROM comments c JOIN users u ON u.id = c.user_id
    WHERE c.post_id = ? ORDER BY c.id ASC LIMIT 20
  `);
  res.json({ posts: posts.map(post => ({ ...post, liked: Boolean(post.liked), comments: commentStmt.all(post.id) })) });
});

app.post("/api/posts", requireAuth, (req, res) => {
  const body = String(req.body.body || "").trim();
  if (!body) return res.status(400).json({ error: "Write something before posting." });
  if (body.length > 1000) return res.status(400).json({ error: "Posts can be up to 1,000 characters." });
  const result = db.prepare("INSERT INTO posts (user_id, body) VALUES (?, ?)").run(req.session.userId, body);
  res.status(201).json({ id: result.lastInsertRowid });
});

app.delete("/api/posts/:id", requireAuth, (req, res) => {
  const id = Number(req.params.id);
  if (!Number.isInteger(id)) return res.status(400).json({ error: "Invalid post." });
  const result = db.prepare("DELETE FROM posts WHERE id = ? AND user_id = ?").run(id, req.session.userId);
  if (!result.changes) return res.status(404).json({ error: "Post not found or you cannot delete it." });
  res.json({ ok: true });
});

app.post("/api/posts/:id/like", requireAuth, (req, res) => {
  const id = Number(req.params.id);
  const post = db.prepare("SELECT id FROM posts WHERE id = ?").get(id);
  if (!post) return res.status(404).json({ error: "Post not found." });
  const existing = db.prepare("SELECT 1 FROM post_likes WHERE post_id = ? AND user_id = ?").get(id, req.session.userId);
  if (existing) db.prepare("DELETE FROM post_likes WHERE post_id = ? AND user_id = ?").run(id, req.session.userId);
  else db.prepare("INSERT INTO post_likes (post_id, user_id) VALUES (?, ?)").run(id, req.session.userId);
  const likes = db.prepare("SELECT COUNT(*) AS count FROM post_likes WHERE post_id = ?").get(id).count;
  res.json({ liked: !existing, likes });
});

app.post("/api/posts/:id/comments", requireAuth, (req, res) => {
  const id = Number(req.params.id);
  const body = String(req.body.body || "").trim();
  if (!body) return res.status(400).json({ error: "Write a comment first." });
  if (body.length > 500) return res.status(400).json({ error: "Comments can be up to 500 characters." });
  const post = db.prepare("SELECT id FROM posts WHERE id = ?").get(id);
  if (!post) return res.status(404).json({ error: "Post not found." });
  const result = db.prepare("INSERT INTO comments (post_id, user_id, body) VALUES (?, ?, ?)").run(id, req.session.userId, body);
  const comment = db.prepare(`SELECT c.id, c.body, c.created_at, c.user_id, u.name FROM comments c JOIN users u ON u.id = c.user_id WHERE c.id = ?`).get(result.lastInsertRowid);
  res.status(201).json({ comment });
});

app.get(/.*/, (req, res) => {
  res.sendFile(path.join(__dirname, "public", "index.html"));
});

const server = app.listen(process.env.PORT || 3000, () => {
  console.log(`Connect is running at http://localhost:${process.env.PORT || 3000}`);
});


process.on("SIGTERM", () => server.close(() => { db.close(); process.exit(0); }));
process.on("SIGINT", () => server.close(() => { db.close(); process.exit(0); }));
