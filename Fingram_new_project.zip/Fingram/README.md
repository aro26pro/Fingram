# Fingram

A brand-new Fingram project, started from scratch.

## Current stage
- Welcome screen starter is in place.
- Brand wordmark: **Fin** in black and **gram** in blue.
- Mobile-first layout.

## Run it
Open `index.html` in a browser, or open this folder in VS Code for the Web and use a static preview/live-server extension if available.

## Project structure
- `index.html` — app entry page
- `src/styles/main.css` — visual styles
- `src/app.js` — interactions
- `src/screens/` — future app screens
- `src/components/` — reusable UI pieces
- `public/images/` — image assets
- `server/` — future backend code

This is an initial front-end scaffold, not yet a complete social network. Account security, data storage, posting, moderation, and reporting still need to be implemented and tested.
