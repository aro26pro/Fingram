// Fingram starter: welcome screen interactions.
document.getElementById("create-account").addEventListener("click", () => {
  alert("Create account screen is the next build step.");
});
document.getElementById("log-in").addEventListener("click", () => {
  alert("Log in screen is the next build step.");
});
