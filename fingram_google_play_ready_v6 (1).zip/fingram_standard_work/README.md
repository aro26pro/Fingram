# Fingram — real login version

This version adds a real server-side authentication flow:
- Create account with name, email, and password
- Passwords are salted and hashed with Node's built-in `scrypt`
- Login creates a server-side session
- Session cookie is HTTP-only
- SQLite persists users in `connect.db`
- Logout destroys the session

## Run locally

1. Install Node.js 20+.
2. In this folder run:
   `npm install`
3. Start:
   `npm start`
4. Open:
   `http://localhost:3000`

For production, set a long random `SESSION_SECRET`, use HTTPS, set the session cookie's `secure` option to true, and use a production session store instead of the default in-memory store.


## Email account creation

Fingram now clearly supports account creation with an email address and password. The signup form validates the email format, requires an 8+ character password, and asks the user to confirm the password. The server stores the normalized email as the account login and stores only a salted password hash.

This does not send a verification email yet. To verify ownership of an email address, connect the app to an email provider and add a verification-token flow.


## Email verification
New accounts must verify their email before login. Configure `SMTP_HOST`, `SMTP_PORT`, `SMTP_USER`, `SMTP_PASS`, `SMTP_SECURE`, `EMAIL_FROM`, and `APP_URL`. Verification links expire after 24 hours, and only a hash of the token is stored.


## Gmail / Google Workspace SMTP setup

Fingram is configured to send verification emails through Gmail SMTP using TLS on port 587. Google's current Gmail help lists `smtp.gmail.com` with TLS/STARTTLS on port 587. citeturn0search0

For authentication, do **not** put your normal Google password in Fingram. Google recommends more secure authentication where possible; when SMTP software needs password-style authentication, an App Password can be used on an account with 2-Step Verification. citeturn0search2

Set the values from `.env.example` in your hosting environment. For Google Workspace, an administrator can alternatively configure Google's SMTP relay service if that fits the organization's mail setup.

### Recommended environment values

- `SMTP_HOST=smtp.gmail.com`
- `SMTP_PORT=587`
- `SMTP_SECURE=false` (STARTTLS)
- `SMTP_USER` = the full Gmail/Workspace sender address
- `SMTP_PASS` = a Google App Password, not the normal account password
- `EMAIL_FROM` = the sender shown to users
- `APP_URL` = the HTTPS address of Fingram

Keep SMTP credentials in environment variables/secrets and never commit them to the source code.

## Friends & Following

This build adds a social connection system:
- Search people by name or email
- Follow/unfollow users
- Send friend requests
- Accept or decline incoming requests
- Automatically accept a request when the recipient has already sent one
- View friends, following, and pending requests from the Home page
- Profile pages show follower/following counts and connection buttons

Connection data is stored in SQLite tables named `follows` and `friend_requests`.

## Google Cloud production hardening

This build is hardened for a Cloud Run deployment with:
- production-only secure session cookies and required SESSION_SECRET
- HTTP security response headers and HSTS in production
- bounded JSON request bodies
- basic per-IP endpoint rate limiting for login, registration, and verification resend
- `/healthz` and `/readyz` endpoints for service health checks
- SQLite WAL mode, foreign keys, and busy timeout
- graceful SIGTERM/SIGINT shutdown
- Docker ignore rules so local databases and secrets are not copied into images

### Important Cloud Run data note
SQLite on the container filesystem is suitable for demos and single-instance testing, but Cloud Run instances have ephemeral local storage and can scale to multiple instances. For a production social network, move application data to a managed database such as Cloud SQL for PostgreSQL (or another managed datastore) and keep SMTP/session secrets in Secret Manager.
