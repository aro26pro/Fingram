# Fingram — fresh front-end prototype

Open `index.html` in a browser. Includes welcome, login, signup, community policy, home, explore, notifications, profile, create-post and settings screens with client-side navigation and demo interactions.

This is a front-end prototype only. Real authentication, persistent storage, private messaging, image uploads, push notifications and server-side moderation/report review are not connected. Do not use it to collect real passwords or personal data.
