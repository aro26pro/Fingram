# Fingram

Fingram is a social communication app with account registration, email verification, profiles, posts, comments, likes, following, friend requests, blocking/reporting backends, and account deletion.

## Cloudflare version

The Cloudflare deployment uses:

- Cloudflare Workers for the application
- Cloudflare D1 for persistent application data
- Resend's HTTPS API for verification email
- Workers Static Assets for the web UI

See `GITHUB_UPLOAD.md` and `CLOUDFLARE_DEPLOY.md` for deployment steps.

## Secrets

Never commit real secrets. Configure `SESSION_SECRET`, `RESEND_API_KEY`, `EMAIL_FROM`, and `APP_URL` as Cloudflare Worker secrets/environment values.

## Google Play

The `android/` directory contains the Android project. Set its `START_URL` to the final HTTPS Fingram Worker URL before building the Play release. Complete privacy policy, account deletion, Data Safety, UGC moderation, content rating, target-audience, signing, and testing requirements before publication.
