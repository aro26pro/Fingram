# Fingram — Cloudflare Free Deployment

This version is adapted for Cloudflare Workers + D1. Cloudflare's current Workers Free plan includes 100,000 requests/day; D1 Free includes 5 million rows read/day, 100,000 rows written/day and 5 GB stored. Limits are enforced, so a busy social network can eventually need a paid plan.

## 1. Create a Cloudflare account
Open the Cloudflare dashboard and create/sign in to an account. The free Workers plan is enough to prototype.

## 2. Open Cloudflare's terminal / Wrangler environment
If you are on a phone, the easiest route is to use the Cloudflare dashboard's Workers setup or connect a GitHub repository. If using a terminal with Wrangler, run:

```bash
npm install
npx wrangler login
```

## 3. Create the D1 database
Run:

```bash
npx wrangler d1 create fingram-db
```

Cloudflare will print a database ID. Put that ID into `wrangler.toml` in place of `REPLACE_WITH_D1_DATABASE_ID`.

## 4. Apply the schema

```bash
npx wrangler d1 migrations apply fingram-db --remote
```

## 5. Add secrets
Never paste these values into chat. Set them in your Cloudflare account:

```bash
npx wrangler secret put SESSION_SECRET
npx wrangler secret put RESEND_API_KEY
npx wrangler secret put EMAIL_FROM
npx wrangler secret put APP_URL
```

For `APP_URL`, use the final HTTPS Worker URL, such as `https://fingram.YOUR-SUBDOMAIN.workers.dev`.

## 6. Deploy

```bash
npx wrangler deploy
```

## Email verification
This build uses Resend's HTTPS API instead of Gmail SMTP, which is a better fit for Workers. Resend currently has a free transactional-email plan with 3,000 emails/month and 100/day. You must configure an allowed sender/domain according to Resend's current onboarding rules.

## Google Play
The Android project is still included. Before building the Play release, change `START_URL` in `android/app/src/main/java/com/fingram/app/MainActivity.java` to your final HTTPS Cloudflare URL and update the internal-domain check for your final hostname if you use a custom domain.

## Important publication items
- Replace the placeholder privacy-policy contact.
- Make the public account-deletion web resource point to a real deletion flow.
- Surface report/block controls in the UI and maintain ongoing moderation.
- Complete Play Console Data Safety, content rating, target audience, and UGC declarations honestly.
- Test the app with Play internal testing before production.
