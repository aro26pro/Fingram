ALTER TABLE users ADD COLUMN username TEXT;
UPDATE users SET username = 'user' || id WHERE username IS NULL OR username = '';
CREATE UNIQUE INDEX IF NOT EXISTS users_username_unique ON users(username);
