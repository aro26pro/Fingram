# Fingram release checklist

This project is prepared for a Google Play **signed AAB** release.

## Before running GitHub Actions

1. Deploy the Fingram backend to a stable HTTPS URL.
2. In Google Play Console, create the app with package name `com.fingram.app`.
3. Configure Play App Signing and create an upload key.
4. Add these GitHub Actions secrets:
   - `PLAY_UPLOAD_KEYSTORE_B64`
   - `PLAY_UPLOAD_KEYSTORE_PASSWORD`
   - `PLAY_UPLOAD_KEY_ALIAS`
   - `PLAY_UPLOAD_KEY_PASSWORD`
5. Do not commit the keystore or passwords to the repository.
6. Create the `fingram_plus_lifetime` one-time product if you want Plus purchases enabled.
7. Configure the backend's Google Play verification credentials before enabling purchases.

## Build

GitHub → Actions → **Fingram Android Release** → Run workflow.

Enter:
- versionCode: a number higher than the latest Play release
- versionName: the new user-visible version
- backend_url: the real HTTPS Fingram backend

The workflow produces a signed `.aab` artifact.

## Release order

Start with **Internal testing**, verify login, email verification, profiles,
posts, moderation/reporting, account deletion, Plus purchase/restore, and
update behavior. Then move to closed/open testing as applicable and finally
Production.

Never upload a build whose backend URL is still `YOUR-FINGRAM`.
