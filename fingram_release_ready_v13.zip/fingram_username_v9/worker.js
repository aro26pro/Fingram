import express from 'express';
import { httpServerHandler } from 'cloudflare:node';
import { env } from 'cloudflare:workers';
import crypto from 'node:crypto';

const app = express();
app.disable('x-powered-by');
app.use(express.json({ limit: '180kb' }));

const SCHEMA = `
CREATE TABLE IF NOT EXISTS users (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  name TEXT NOT NULL,
  username TEXT,
  email TEXT NOT NULL UNIQUE,
  password_hash TEXT NOT NULL,
  salt TEXT NOT NULL,
  email_verified INTEGER NOT NULL DEFAULT 0,
  verification_token_hash TEXT,
  verification_expires_at INTEGER,
  bio TEXT NOT NULL DEFAULT '',
  avatar_data TEXT,
  created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);
CREATE TABLE IF NOT EXISTS posts (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  user_id INTEGER NOT NULL,
  body TEXT NOT NULL,
  created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
);
CREATE TABLE IF NOT EXISTS post_likes (
  post_id INTEGER NOT NULL,
  user_id INTEGER NOT NULL,
  created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (post_id, user_id),
  FOREIGN KEY (post_id) REFERENCES posts(id) ON DELETE CASCADE,
  FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
);
CREATE TABLE IF NOT EXISTS comments (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  post_id INTEGER NOT NULL,
  user_id INTEGER NOT NULL,
  body TEXT NOT NULL,
  created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (post_id) REFERENCES posts(id) ON DELETE CASCADE,
  FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
);
CREATE TABLE IF NOT EXISTS follows (
  follower_id INTEGER NOT NULL,
  following_id INTEGER NOT NULL,
  created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (follower_id, following_id),
  CHECK (follower_id <> following_id),
  FOREIGN KEY (follower_id) REFERENCES users(id) ON DELETE CASCADE,
  FOREIGN KEY (following_id) REFERENCES users(id) ON DELETE CASCADE
);
CREATE TABLE IF NOT EXISTS blocks (
  blocker_id INTEGER NOT NULL,
  blocked_id INTEGER NOT NULL,
  created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (blocker_id, blocked_id),
  CHECK (blocker_id <> blocked_id),
  FOREIGN KEY (blocker_id) REFERENCES users(id) ON DELETE CASCADE,
  FOREIGN KEY (blocked_id) REFERENCES users(id) ON DELETE CASCADE
);
CREATE TABLE IF NOT EXISTS reports (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  reporter_id INTEGER NOT NULL,
  post_id INTEGER,
  reported_user_id INTEGER,
  reason TEXT NOT NULL,
  details TEXT NOT NULL DEFAULT '',
  status TEXT NOT NULL DEFAULT 'open',
  created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (reporter_id) REFERENCES users(id) ON DELETE CASCADE,
  FOREIGN KEY (post_id) REFERENCES posts(id) ON DELETE CASCADE,
  FOREIGN KEY (reported_user_id) REFERENCES users(id) ON DELETE CASCADE
);
CREATE TABLE IF NOT EXISTS friend_requests (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  sender_id INTEGER NOT NULL,
  receiver_id INTEGER NOT NULL,
  status TEXT NOT NULL DEFAULT 'pending',
  created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
  CHECK (sender_id <> receiver_id),
  FOREIGN KEY (sender_id) REFERENCES users(id) ON DELETE CASCADE,
  FOREIGN KEY (receiver_id) REFERENCES users(id) ON DELETE CASCADE
);
CREATE UNIQUE INDEX IF NOT EXISTS users_username_unique ON users(username);
CREATE UNIQUE INDEX IF NOT EXISTS friend_pair_unique ON friend_requests(sender_id, receiver_id);
CREATE INDEX IF NOT EXISTS idx_posts_user_id ON posts(user_id, id DESC);
CREATE INDEX IF NOT EXISTS idx_comments_post_id ON comments(post_id, id ASC);
CREATE INDEX IF NOT EXISTS idx_likes_post_id ON post_likes(post_id);
CREATE INDEX IF NOT EXISTS idx_follows_following_id ON follows(following_id);
CREATE INDEX IF NOT EXISTS idx_friend_receiver_status ON friend_requests(receiver_id, status);
`;

let schemaReady;
async function dbReady() {
  if (!schemaReady) schemaReady = (async()=>{ await env.DB.exec(SCHEMA); try { await run('ALTER TABLE users ADD COLUMN username TEXT'); } catch {} await run("UPDATE users SET username = 'user' || id WHERE username IS NULL OR username = ''"); await run('CREATE UNIQUE INDEX IF NOT EXISTS users_username_unique ON users(username)'); try { await run('ALTER TABLE users ADD COLUMN avatar_data TEXT'); } catch {} })();
  await schemaReady;
}
const stmt = (sql, ...args) => env.DB.prepare(sql).bind(...args);
const first = async (sql, ...args) => (await stmt(sql, ...args).first()) ?? null;
const all = async (sql, ...args) => (await stmt(sql, ...args).all()).results ?? [];
const run = async (sql, ...args) => {
  const r = await stmt(sql, ...args).run();
  return { changes: Number(r.meta?.changes ?? 0), lastInsertRowid: Number(r.meta?.last_row_id ?? 0) };
};

function b64url(bytes) {
  return Buffer.from(bytes).toString('base64').replaceAll('+','-').replaceAll('/','_').replaceAll('=','');
}
function fromB64url(s) { return Buffer.from(s.replaceAll('-','+').replaceAll('_','/'), 'base64'); }
async function hmac(value) {
  const key = await crypto.subtle.importKey('raw', new TextEncoder().encode(env.SESSION_SECRET || 'change-me'), {name:'HMAC',hash:'SHA-256'}, false, ['sign']);
  return b64url(await crypto.subtle.sign('HMAC', key, new TextEncoder().encode(value)));
}
async function makeSession(userId) {
  const exp = Math.floor(Date.now()/1000) + 60*60*24*7;
  const payload = `${userId}.${exp}`;
  return `${payload}.${await hmac(payload)}`;
}
async function readSession(req) {
  const raw = req.headers.cookie || '';
  const match = raw.match(/(?:^|;\s*)fingram_session=([^;]+)/);
  if (!match) return null;
  const value = decodeURIComponent(match[1]);
  const parts = value.split('.');
  if (parts.length !== 3) return null;
  const [userId, exp, sig] = parts;
  if (!/^\d+$/.test(userId) || !/^\d+$/.test(exp) || Number(exp) < Math.floor(Date.now()/1000)) return null;
  const expected = await hmac(`${userId}.${exp}`);
  const a=Buffer.from(sig), b=Buffer.from(expected);
  if (a.length !== b.length || !crypto.timingSafeEqual(a,b)) return null;
  return Number(userId);
}
function setSession(res, token) {
  res.setHeader('Set-Cookie', `fingram_session=${encodeURIComponent(token)}; Path=/; Max-Age=604800; HttpOnly; Secure; SameSite=Lax`);
}
function clearSession(res) {
  res.setHeader('Set-Cookie', 'fingram_session=; Path=/; Max-Age=0; HttpOnly; Secure; SameSite=Lax');
}

const rateMap = new Map();
function rateLimit(windowMs, max) {
  return (req, res, next) => {
    const key = `${req.ip || req.headers['cf-connecting-ip'] || 'unknown'}:${req.path}`;
    const now = Date.now();
    let item = rateMap.get(key);
    if (!item || now-item.start >= windowMs) item = {start:now,count:0};
    item.count++; rateMap.set(key,item);
    if (item.count > max) return res.status(429).json({error:'Too many requests. Please try again shortly.'});
    next();
  };
}

app.use(async (req,res,next)=>{ await dbReady(); next(); });
app.use((req,res,next)=>{
  res.setHeader('X-Content-Type-Options','nosniff');
  res.setHeader('X-Frame-Options','DENY');
  res.setHeader('Referrer-Policy','strict-origin-when-cross-origin');
  res.setHeader('Permissions-Policy','camera=(), microphone=(), geolocation=()');
  res.setHeader('Cross-Origin-Opener-Policy','same-origin');
  res.setHeader('Strict-Transport-Security','max-age=31536000; includeSubDomains');
  next();
});

function publicUser(u){ return {id:u.id,name:u.name,username:u.username||`user${u.id}`,email:u.email,bio:u.bio||'',avatar_data:u.avatar_data||null,created_at:u.created_at}; }
async function requireAuth(req,res,next){
  const id = await readSession(req);
  if (!id) return res.status(401).json({error:'You are not logged in.'});
  const user = await first('SELECT id FROM users WHERE id = ?', id);
  if (!user) { clearSession(res); return res.status(401).json({error:'You are not logged in.'}); }
  req.userId = id; next();
}
function hashPassword(password, salt = crypto.randomBytes(16).toString('hex')) {
  const hash = crypto.scryptSync(password, salt, 64).toString('hex');
  return {hash,salt};
}
function makeVerificationToken(){return crypto.randomBytes(32).toString('hex');}
function hashToken(token){return crypto.createHash('sha256').update(token).digest('hex');}
async function sendVerificationEmail(email,name,token){
  if (!env.RESEND_API_KEY) throw new Error('RESEND_API_KEY is not configured.');
  const base=(env.APP_URL || '').replace(/\/$/,'');
  if (!base) throw new Error('APP_URL is not configured.');
  const url=`${base}/verify-email?token=${encodeURIComponent(token)}`;
  const safeName=String(name).replace(/[<>&"]/g,'');
  const r=await fetch('https://api.resend.com/emails',{method:'POST',headers:{Authorization:`Bearer ${env.RESEND_API_KEY}`,'Content-Type':'application/json'},body:JSON.stringify({from:env.EMAIL_FROM||'Fingram <onboarding@resend.dev>',to:[email],subject:'Verify your Fingram email',text:`Hi ${name},\n\nVerify your Fingram email: ${url}\n\nThis link expires in 24 hours.`,html:`<p>Hi ${safeName},</p><p>Verify your Fingram email to activate your account:</p><p><a href="${url}">Verify my email</a></p><p>This link expires in 24 hours.</p>`})});
  if (!r.ok) throw new Error(`Email provider returned ${r.status}`);
}

app.get('/healthz',(req,res)=>res.json({ok:true,service:'fingram',platform:'cloudflare'}));
app.get('/readyz',async(req,res)=>{try{await first('SELECT 1 AS ok');res.json({ok:true});}catch{res.status(503).json({ok:false});}});

app.get('/verify-email',async(req,res)=>{
  const token=String(req.query.token||'');
  if(!token)return res.status(400).send('<h2>Invalid verification link</h2><p>This link is missing a token.</p>');
  const user=await first('SELECT id,email_verified,verification_expires_at FROM users WHERE verification_token_hash = ?',hashToken(token));
  if(!user)return res.status(400).send('<h2>Invalid verification link</h2><p>The link may have already been used.</p>');
  if(user.email_verified)return res.send('<h2>Email already verified</h2><p>You can return to Fingram and log in.</p>');
  if(!user.verification_expires_at || user.verification_expires_at < Date.now())return res.status(410).send('<h2>Verification link expired</h2><p>Please request a new verification email.</p>');
  await run('UPDATE users SET email_verified=1, verification_token_hash=NULL, verification_expires_at=NULL WHERE id=?',user.id);
  res.send('<!doctype html><meta name="viewport" content="width=device-width"><title>Fingram email verified</title><style>body{font-family:system-ui;background:#f5f7fb;display:grid;place-items:center;min-height:100vh}.card{background:white;padding:32px;border-radius:18px;text-align:center;box-shadow:0 15px 45px #0001}a{display:inline-block;margin-top:14px;background:#2563eb;color:white;padding:11px 18px;border-radius:9px;text-decoration:none}</style><div class="card"><h1>✓ Email verified</h1><p>Your Fingram account is ready.</p><a href="/">Log in to Fingram</a></div>');
});

app.post('/api/resend-verification',rateLimit(15*60*1000,5),async(req,res)=>{
  const email=String(req.body.email||'').trim().toLowerCase();
  const user=await first('SELECT id,name,email,email_verified FROM users WHERE email=?',email);
  if(!user||user.email_verified)return res.json({ok:true});
  const token=makeVerificationToken();
  await run('UPDATE users SET verification_token_hash=?,verification_expires_at=? WHERE id=?',hashToken(token),Date.now()+24*60*60*1000,user.id);
  try{await sendVerificationEmail(user.email,user.name,token);res.json({ok:true});}catch{res.status(503).json({error:'Could not send the verification email.'});}
});

app.post('/api/register',rateLimit(15*60*1000,5),async(req,res)=>{
  const name=String(req.body.name||'').trim(),username=String(req.body.username||'').trim().toLowerCase(),email=String(req.body.email||'').trim().toLowerCase(),password=String(req.body.password||'');
  if(name.length<2)return res.status(400).json({error:'Enter your name.'});
  if(!/^[a-z0-9_]{3,20}$/.test(username))return res.status(400).json({error:'Username must be 3–20 characters using letters, numbers, or underscores.'});
  if(!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email))return res.status(400).json({error:'Enter a valid email.'});
  if(email.length>254)return res.status(400).json({error:'Email address is too long.'});
  if(password.length<8)return res.status(400).json({error:'Password must be at least 8 characters.'});
  try{
    const {hash,salt}=hashPassword(password);
    const r=await run('INSERT INTO users(name,email,password_hash,salt) VALUES(?,?,?,?)',name,email,hash,salt);
    const id=r.lastInsertRowid,token=makeVerificationToken();
    await run('UPDATE users SET verification_token_hash=?,verification_expires_at=? WHERE id=?',hashToken(token),Date.now()+24*60*60*1000,id);
    try{await sendVerificationEmail(email,name,token);}catch{await run('DELETE FROM users WHERE id=?',id);return res.status(503).json({error:'We could not send the verification email. Check your email setup and try again.'});}
    res.status(201).json({verificationRequired:true,email});
  }catch(e){if(String(e.message).includes('UNIQUE'))return res.status(409).json({error:'That email or username is already in use.'});res.status(500).json({error:'Could not create the account.'});}
});

app.post('/api/login',rateLimit(15*60*1000,10),async(req,res)=>{
  const email=String(req.body.email||'').trim().toLowerCase(),password=String(req.body.password||'');
  const user=await first('SELECT * FROM users WHERE email=?',email);
  if(!user)return res.status(401).json({error:'Email or password is incorrect.'});
  const {hash}=hashPassword(password,user.salt);
  const valid=crypto.timingSafeEqual(Buffer.from(hash,'hex'),Buffer.from(user.password_hash,'hex'));
  if(!valid)return res.status(401).json({error:'Email or password is incorrect.'});
  if(!user.email_verified)return res.status(403).json({error:'Please verify your email before logging in.',code:'EMAIL_NOT_VERIFIED'});
  setSession(res,await makeSession(user.id));
  res.json({user:publicUser(user)});
});
app.post('/api/logout',async(req,res)=>{clearSession(res);res.json({ok:true});});
app.get('/api/me',async(req,res)=>{const id=await readSession(req);if(!id)return res.json({user:null});const u=await first('SELECT id,name,username,email,bio,avatar_data,created_at FROM users WHERE id=?',id);if(!u){clearSession(res);return res.json({user:null});}res.json({user:publicUser(u)});});

app.post('/api/account/delete',requireAuth,rateLimit(15*60*1000,3),async(req,res)=>{await run('DELETE FROM users WHERE id=?',req.userId);clearSession(res);res.json({ok:true});});
app.post('/api/users/:id/block',requireAuth,async(req,res)=>{const id=Number(req.params.id);if(!Number.isInteger(id)||id===req.userId)return res.status(400).json({error:'Invalid user.'});if(!await first('SELECT id FROM users WHERE id=?',id))return res.status(404).json({error:'User not found.'});const ex=await first('SELECT 1 FROM blocks WHERE blocker_id=? AND blocked_id=?',req.userId,id);if(ex){await run('DELETE FROM blocks WHERE blocker_id=? AND blocked_id=?',req.userId,id);}else{await run('INSERT INTO blocks(blocker_id,blocked_id) VALUES(?,?)',req.userId,id);await run('DELETE FROM follows WHERE (follower_id=? AND following_id=?) OR (follower_id=? AND following_id=?)',req.userId,id,id,req.userId);await run('DELETE FROM friend_requests WHERE (sender_id=? AND receiver_id=?) OR (sender_id=? AND receiver_id=?)',req.userId,id,id,req.userId);}res.json({blocked:!ex});});
app.post('/api/reports',requireAuth,rateLimit(15*60*1000,10),async(req,res)=>{const postId=req.body.postId==null?null:Number(req.body.postId),reportedUserId=req.body.userId==null?null:Number(req.body.userId),reason=String(req.body.reason||'').trim().slice(0,80),details=String(req.body.details||'').trim().slice(0,500);if(!reason)return res.status(400).json({error:'Choose a reason.'});if(!postId&&!reportedUserId)return res.status(400).json({error:'Choose a post or user to report.'});if(postId&&!await first('SELECT id FROM posts WHERE id=?',postId))return res.status(404).json({error:'Post not found.'});if(reportedUserId&&!await first('SELECT id FROM users WHERE id=?',reportedUserId))return res.status(404).json({error:'User not found.'});await run('INSERT INTO reports(reporter_id,post_id,reported_user_id,reason,details) VALUES(?,?,?,?,?)',req.userId,postId,reportedUserId,reason,details);res.status(201).json({ok:true});});

app.get('/api/profile/:id',requireAuth,async(req,res)=>{const id=Number(req.params.id);if(!Number.isInteger(id))return res.status(400).json({error:'Invalid profile.'});const user=await first(`SELECT id,name,username,bio,avatar_data,created_at,(SELECT COUNT(*) FROM posts p WHERE p.user_id=users.id) AS post_count,(SELECT COUNT(*) FROM follows f WHERE f.following_id=users.id) AS followers_count,(SELECT COUNT(*) FROM follows f WHERE f.follower_id=users.id) AS following_count FROM users WHERE id=?`,id);if(!user)return res.status(404).json({error:'Profile not found.'});const posts=await all(`SELECT p.id,p.user_id,p.body,p.created_at,(SELECT COUNT(*) FROM post_likes pl WHERE pl.post_id=p.id) AS likes,EXISTS(SELECT 1 FROM post_likes pl2 WHERE pl2.post_id=p.id AND pl2.user_id=?) AS liked,(SELECT COUNT(*) FROM comments c WHERE c.post_id=p.id) AS comments_count FROM posts p WHERE p.user_id=? ORDER BY p.id DESC LIMIT 50`,req.userId,id);const following=!!await first('SELECT 1 FROM follows WHERE follower_id=? AND following_id=?',req.userId,id);let friendStatus='none';const outgoing=await first('SELECT status FROM friend_requests WHERE sender_id=? AND receiver_id=? ORDER BY id DESC LIMIT 1',req.userId,id);const incoming=await first('SELECT status FROM friend_requests WHERE sender_id=? AND receiver_id=? ORDER BY id DESC LIMIT 1',id,req.userId);if(outgoing?.status==='accepted'||incoming?.status==='accepted')friendStatus='friends';else if(outgoing?.status==='pending')friendStatus='outgoing';else if(incoming?.status==='pending')friendStatus='incoming';res.json({profile:{...user,following,friend_status:friendStatus},posts:posts.map(p=>({...p,liked:!!p.liked}))});});
app.patch('/api/profile',requireAuth,async(req,res)=>{const name=String(req.body.name||'').trim(),username=String(req.body.username||'').trim().toLowerCase(),bio=String(req.body.bio||'').trim(),avatar=req.body.avatar_data==null?undefined:String(req.body.avatar_data);if(name.length<2||name.length>80)return res.status(400).json({error:'Name must be 2–80 characters.'});if(!/^[a-z0-9_]{3,20}$/.test(username))return res.status(400).json({error:'Username must be 3–20 characters using letters, numbers, or underscores.'});if(bio.length>160)return res.status(400).json({error:'Bio can be up to 160 characters.'});if(avatar!==undefined&&avatar!==''&&!/^data:image\/(jpeg|png|webp);base64,[A-Za-z0-9+/=]+$/.test(avatar))return res.status(400).json({error:'Profile picture must be a JPEG, PNG, or WebP image.'});if(avatar!==undefined&&avatar.length>140000)return res.status(400).json({error:'Profile picture is too large. Please choose a smaller image.'});try{if(avatar===undefined)await run('UPDATE users SET name=?,username=?,bio=? WHERE id=?',name,username,bio,req.userId);else if(avatar==='')await run('UPDATE users SET name=?,username=?,bio=?,avatar_data=NULL WHERE id=?',name,username,bio,req.userId);else await run('UPDATE users SET name=?,username=?,bio=?,avatar_data=? WHERE id=?',name,username,bio,avatar,req.userId);}catch(err){if(String(err.message||'').includes('UNIQUE'))return res.status(409).json({error:'That username is already in use.'});throw err;}res.json({user:publicUser(await first('SELECT id,name,username,email,bio,avatar_data,created_at FROM users WHERE id=?',req.userId))});});

app.get('/api/users/search',requireAuth,async(req,res)=>{const q=String(req.query.q||'').trim();if(q.length<2)return res.json({users:[]});const like=`%${q.replace(/[%_]/g,'\\$&')}%`;const users=await all(`SELECT id,name,username,bio,avatar_data,(SELECT COUNT(*) FROM follows f WHERE f.following_id=users.id) AS followers_count FROM users WHERE id<>? AND (name LIKE ? ESCAPE '\\' OR username LIKE ? ESCAPE '\\' OR email LIKE ? ESCAPE '\\') ORDER BY name COLLATE NOCASE LIMIT 20`,req.userId,like,like,like);res.json({users});});
app.get('/api/friends',requireAuth,async(req,res)=>{const id=req.userId;const friends=await all(`SELECT u.id,u.name,u.username,u.avatar_data,u.bio,u.created_at FROM friend_requests fr JOIN users u ON u.id=CASE WHEN fr.sender_id=? THEN fr.receiver_id ELSE fr.sender_id END WHERE (fr.sender_id=? OR fr.receiver_id=?) AND fr.status='accepted' ORDER BY u.name COLLATE NOCASE`,id,id,id);const following=await all(`SELECT u.id,u.name,u.username,u.avatar_data,u.bio FROM follows f JOIN users u ON u.id=f.following_id WHERE f.follower_id=? ORDER BY u.name COLLATE NOCASE`,id);const incoming=await all(`SELECT fr.id,u.id AS user_id,u.name,u.username,u.avatar_data,u.bio FROM friend_requests fr JOIN users u ON u.id=fr.sender_id WHERE fr.receiver_id=? AND fr.status='pending' ORDER BY fr.id DESC`,id);res.json({friends,following,incoming});});
app.post('/api/users/:id/follow',requireAuth,async(req,res)=>{const id=Number(req.params.id);if(!Number.isInteger(id)||id===req.userId)return res.status(400).json({error:'Invalid user.'});if(!await first('SELECT id FROM users WHERE id=?',id))return res.status(404).json({error:'User not found.'});const ex=await first('SELECT 1 FROM follows WHERE follower_id=? AND following_id=?',req.userId,id);if(ex)await run('DELETE FROM follows WHERE follower_id=? AND following_id=?',req.userId,id);else await run('INSERT INTO follows(follower_id,following_id) VALUES(?,?)',req.userId,id);const followers=await first('SELECT COUNT(*) AS count FROM follows WHERE following_id=?',id);res.json({following:!ex,followers:Number(followers.count)});});
app.post('/api/users/:id/friend-request',requireAuth,async(req,res)=>{const id=Number(req.params.id);if(!Number.isInteger(id)||id===req.userId)return res.status(400).json({error:'Invalid user.'});if(!await first('SELECT id FROM users WHERE id=?',id))return res.status(404).json({error:'User not found.'});const reverse=await first('SELECT id,status FROM friend_requests WHERE sender_id=? AND receiver_id=? ORDER BY id DESC LIMIT 1',id,req.userId);if(reverse?.status==='pending'){await run("UPDATE friend_requests SET status='accepted',updated_at=CURRENT_TIMESTAMP WHERE id=?",reverse.id);return res.json({status:'friends'});}const ex=await first('SELECT id,status FROM friend_requests WHERE sender_id=? AND receiver_id=? ORDER BY id DESC LIMIT 1',req.userId,id);if(ex?.status==='pending')return res.json({status:'outgoing'});if(ex?.status==='accepted')return res.json({status:'friends'});if(ex)await run("UPDATE friend_requests SET status='pending',updated_at=CURRENT_TIMESTAMP WHERE id=?",ex.id);else await run('INSERT INTO friend_requests(sender_id,receiver_id) VALUES(?,?)',req.userId,id);res.json({status:'outgoing'});});
app.post('/api/friend-requests/:id/accept',requireAuth,async(req,res)=>{const id=Number(req.params.id);const r=await first("SELECT id FROM friend_requests WHERE id=? AND receiver_id=? AND status='pending'",id,req.userId);if(!r)return res.status(404).json({error:'Friend request not found.'});await run("UPDATE friend_requests SET status='accepted',updated_at=CURRENT_TIMESTAMP WHERE id=?",id);res.json({status:'friends'});});
app.post('/api/friend-requests/:id/decline',requireAuth,async(req,res)=>{const id=Number(req.params.id);const r=await run("UPDATE friend_requests SET status='declined',updated_at=CURRENT_TIMESTAMP WHERE id=? AND receiver_id=? AND status='pending'",id,req.userId);if(!r.changes)return res.status(404).json({error:'Friend request not found.'});res.json({status:'declined'});});

app.get('/api/feed',requireAuth,async(req,res)=>{const posts=await all(`SELECT p.id,p.user_id,p.body,p.created_at,u.name,u.username,u.avatar_data,(SELECT COUNT(*) FROM post_likes pl WHERE pl.post_id=p.id) AS likes,EXISTS(SELECT 1 FROM post_likes pl2 WHERE pl2.post_id=p.id AND pl2.user_id=?) AS liked,(SELECT COUNT(*) FROM comments c WHERE c.post_id=p.id) AS comments_count FROM posts p JOIN users u ON u.id=p.user_id ORDER BY p.id DESC LIMIT 50`,req.userId);const out=[];for(const p of posts){const comments=await all(`SELECT c.id,c.body,c.created_at,c.user_id,u.name,u.avatar_data FROM comments c JOIN users u ON u.id=c.user_id WHERE c.post_id=? ORDER BY c.id ASC LIMIT 20`,p.id);out.push({...p,liked:!!p.liked,comments});}res.json({posts:out});});
app.post('/api/posts',requireAuth,async(req,res)=>{const body=String(req.body.body||'').trim();if(!body)return res.status(400).json({error:'Write something before posting.'});if(body.length>1000)return res.status(400).json({error:'Posts can be up to 1,000 characters.'});const r=await run('INSERT INTO posts(user_id,body) VALUES(?,?)',req.userId,body);res.status(201).json({id:r.lastInsertRowid});});
app.delete('/api/posts/:id',requireAuth,async(req,res)=>{const id=Number(req.params.id);if(!Number.isInteger(id))return res.status(400).json({error:'Invalid post.'});const r=await run('DELETE FROM posts WHERE id=? AND user_id=?',id,req.userId);if(!r.changes)return res.status(404).json({error:'Post not found or you cannot delete it.'});res.json({ok:true});});
app.post('/api/posts/:id/like',requireAuth,async(req,res)=>{const id=Number(req.params.id);if(!await first('SELECT id FROM posts WHERE id=?',id))return res.status(404).json({error:'Post not found.'});const ex=await first('SELECT 1 FROM post_likes WHERE post_id=? AND user_id=?',id,req.userId);if(ex)await run('DELETE FROM post_likes WHERE post_id=? AND user_id=?',id,req.userId);else await run('INSERT INTO post_likes(post_id,user_id) VALUES(?,?)',id,req.userId);const likes=await first('SELECT COUNT(*) AS count FROM post_likes WHERE post_id=?',id);res.json({liked:!ex,likes:Number(likes.count)});});
app.post('/api/posts/:id/comments',requireAuth,async(req,res)=>{const id=Number(req.params.id),body=String(req.body.body||'').trim();if(!body)return res.status(400).json({error:'Write a comment first.'});if(body.length>500)return res.status(400).json({error:'Comments can be up to 500 characters.'});if(!await first('SELECT id FROM posts WHERE id=?',id))return res.status(404).json({error:'Post not found.'});const r=await run('INSERT INTO comments(post_id,user_id,body) VALUES(?,?,?)',id,req.userId,body);const comment=await first('SELECT c.id,c.body,c.created_at,c.user_id,u.name FROM comments c JOIN users u ON u.id=c.user_id WHERE c.id=?',r.lastInsertRowid);res.status(201).json({comment});});

app.get('/privacy',(req,res)=>res.type('html').send(`<!doctype html><meta name="viewport" content="width=device-width"><title>Fingram Privacy Policy</title><main style="font-family:system-ui;max-width:760px;margin:40px auto;padding:0 20px;line-height:1.6"><h1>Fingram Privacy Policy</h1><p>Fingram uses account information, authentication data, profile content and social activity to provide the service. Verification emails are sent through the configured transactional email provider.</p><h2>Account deletion</h2><p>Users can request deletion from the app. Associated application records are deleted subject to limited legal or security retention requirements.</p><h2>Contact</h2><p>Replace this placeholder with the real developer privacy contact before publishing on Google Play.</p></main>`));
app.get('/terms',(req,res)=>res.type('html').send(`<!doctype html><meta name="viewport" content="width=device-width"><title>Fingram Terms</title><main style="font-family:system-ui;max-width:760px;margin:40px auto;padding:0 20px;line-height:1.6"><h1>Fingram Terms of Use</h1><p>Use Fingram respectfully. Do not harass, threaten, impersonate, spam, or post illegal or abusive content. Content or accounts may be removed for policy violations.</p><p>Replace this placeholder with the real developer/contact information before publishing.</p></main>`));

app.use(async(req,res)=>{
  try {
    const asset = await env.ASSETS.fetch(new Request(req.originalUrl ? new URL(req.originalUrl, req.protocol+'://'+req.get('host')).toString() : req.url, {method:req.method,headers:req.headers}));
    if (asset.status === 404 && req.method === 'GET') {
      const index = await env.ASSETS.fetch(new Request(new URL('/', req.protocol+'://'+req.get('host')).toString()));
      res.status(index.status); index.headers.forEach((v,k)=>res.setHeader(k,v)); res.send(Buffer.from(await index.arrayBuffer())); return;
    }
    res.status(asset.status); asset.headers.forEach((v,k)=>res.setHeader(k,v)); res.send(Buffer.from(await asset.arrayBuffer()));
  } catch { res.status(500).send('Fingram asset error'); }
});

app.listen(8787);
export default httpServerHandler({ port: 8787 });
