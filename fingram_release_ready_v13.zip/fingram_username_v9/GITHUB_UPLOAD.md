# Upload Fingram to GitHub

This package is ready to place in the `aro26pro/Fingram` repository.

## Easiest method in Codespaces
1. Open the Fingram Codespace.
2. Open the terminal.
3. Upload the latest ZIP if it is not already in the workspace.
4. Extract it, then copy the project files into the repository root.
5. Commit and push the changes.

Example:

```bash
unzip fingram_profile_pictures_v10.zip
cd fingram_username_v9
git add .
git commit -m "Add Fingram profile pictures"
git push origin main
```

Do not commit `.env`, passwords, Gmail App Passwords, API keys, or other secrets.
