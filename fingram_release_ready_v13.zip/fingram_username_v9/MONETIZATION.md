# Fingram ad-free monetization

Fingram is intentionally **ad-free**. The included model uses an optional **one-time Fingram Plus purchase** through Google Play Billing.

## Product

Create this one-time product in Google Play Console:

- Product ID: `fingram_plus_lifetime`
- Type: one-time product / non-consumable
- Suggested display name: `Fingram Plus`
- Suggested description: `Support Fingram and unlock Plus features.`

The Android app uses Google Play Billing Library 9.1.0. Google currently lists 9.1.0 as the latest release, and version 9 remains supported for new apps and updates. See the official Android documentation for the current policy and release details.

## What Plus unlocks

- Plus badge on the profile
- Up to 5,000 characters per post instead of 1,000
- No ads (Fingram has no ads for anyone)

## Server verification

The server does **not** trust the Android client to grant premium access. It verifies the Google Play purchase token through the Google Play Developer API before storing the entitlement.

Set these environment variables on the backend:

```text
GOOGLE_PLAY_PACKAGE_NAME=com.fingram.app
GOOGLE_PLAY_PREMIUM_PRODUCT_ID=fingram_plus_lifetime
GOOGLE_PLAY_SERVICE_ACCOUNT_JSON={...service account JSON...}
```

Never commit the service-account JSON or other credentials to GitHub.

## Important before release

1. Create the product in Play Console.
2. Link the Google Play Developer API service account to the Play Console developer account with only the permissions needed for purchase management.
3. Publish the app to an internal test track so Google Play can serve the product.
4. Test purchase, restore, refund/void behavior, and account deletion.
5. Replace the placeholder backend URL in `android/app/src/main/java/com/fingram/app/MainActivity.java` with the real HTTPS Fingram backend URL.

Digital purchases in a Play-distributed app generally need to use Google Play Billing unless a specific regional program applies. The official policy can change, so re-check it before release.
