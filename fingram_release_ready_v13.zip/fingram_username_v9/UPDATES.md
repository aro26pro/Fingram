# Fingram updates

Fingram is configured for normal Google Play updates and Play In-App Updates.

## Versioning
- Current versionName: 1.1.0
- Current versionCode: 2
- Every future Google Play release must use the same applicationId (`com.fingram.app`) and a higher versionCode.
- Keep the same Play App Signing identity for updates.

## In-app updates
The Android shell uses Google Play's Play In-App Update library 2.1.0. When Google Play has a compatible update, Fingram can download it through the Play update flow.

In-app updates work when the installed app came from Google Play (or an eligible Play testing track) and a newer version is available there. A locally installed APK will not magically update from an APK file; publish the newer signed version through the same Play listing.

## Releasing an update
1. Increase `versionCode`.
2. Update `versionName`.
3. Build a signed Android App Bundle (AAB).
4. Upload it to the same Google Play app.
5. Roll it out to your chosen testing/production track.

Google Play compares the higher version code and can then offer the update to existing users.
