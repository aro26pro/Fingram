# Fingram Profile Pictures

Fingram now supports profile pictures.

## What it does
- Users can choose a JPEG, PNG, or WebP image from their phone.
- The browser automatically resizes the image to a small square JPEG before upload.
- The profile picture appears on the profile, home feed, comments, people search, and friends lists.
- Users can replace or remove their picture from **Edit profile**.
- Images are validated server-side and limited in size.

## Storage note
The current version stores the resized image in the user record as a data URL. This keeps the GitHub/Cloudflare version simple and avoids requiring an image-upload service. For a large production deployment, move avatar storage to object storage such as Cloudflare R2 or another managed object store.
